package com.hengki.gestureprojectfany

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.PopupMenu
import android.widget.Toast
import androidx.core.view.GestureDetectorCompat
import com.hengki.gesture.R
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Exception


class MainActivity : AppCompatActivity() , GestureDetector.OnGestureListener ,
    GestureDetector.OnDoubleTapListener {

    //variabel deteksi gesture
    var gDetector : GestureDetectorCompat? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //class turunan gesturedetectorcompat
        this.gDetector = GestureDetectorCompat(this, this)

        //mendeteksi ketukan ganda
        gDetector?.setOnDoubleTapListener(this)
    }

    //mencegah tap
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        this.gDetector?.onTouchEvent(event)
        return  super.onTouchEvent(event)
    }

    //implementasi untuk ketukan kebawah
    override fun onDown(event : MotionEvent?): Boolean {
        gesture_status.text = "onDown"
        return true
    }

    //implementasi untuk melempar / onFling
    override fun onFling(
        event1: MotionEvent,
        event2: MotionEvent,
        velocityX: Float,
        velocityY: Float
    ): Boolean {
        gesture_status.text = "onFling"
        return true
    }
    /////////////////////////////////////////////////////////////////////
    //implementasi untuk ketukan lama
    override fun onLongPress(event: MotionEvent?) {
        gesture_status.text = "onLongPress"
        gesture_status.setOnLongClickListener() {
            val popupMenu = PopupMenu (this, it)
            popupMenu.setOnMenuItemClickListener {
                    item ->  when (item.itemId){
                R.id.menu_share ->{
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com" ))
                    startActivity(intent)
                    true
                }
                R.id.menu_info ->{
                    Toast.makeText(this, "Ada Toast", Toast.LENGTH_LONG).show()
                    true
                }
                else -> false
            }
            }
            popupMenu.inflate(R.menu.main_menu)
            try {
                val fieldMPopup = PopupMenu::class.java.getDeclaredField("mPopup")
                fieldMPopup.isAccessible = true
                val mPopup = fieldMPopup.get(popupMenu)
                mPopup.javaClass
                    .getDeclaredMethod("setForceShowIcon", Boolean::class.java)
                    .invoke(mPopup, true)
            }
            catch (e: Exception){
                Log.e("Main", "Error showing menu icons .", e)
            }
            finally {
                popupMenu.show()
            }
            true
        }

    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //implementasi untuk scroll
    override fun onScroll(
        e1: MotionEvent,
        e2: MotionEvent,
        distanceX: Float,
        distanceY: Float
    ): Boolean {
        gesture_status.text = "onScroll"
        return true
    }

    //implementasi untuk menekan / showpress
    override fun onShowPress(event: MotionEvent?) {
        gesture_status.text = "onShowPress"
    }


    //implementasi untuk sekali ketuk
    override fun onSingleTapUp(event: MotionEvent): Boolean {
        gesture_status.text = "onSingleTapUop"
        return true
    }

    //implementasi untuk ketukan berulang 2x
    override fun onDoubleTap(event: MotionEvent?): Boolean {
        gesture_status.text = "onDoubleTap"
        return true
    }

    //implementasi untuk ketukan berulang - ulang
    override fun onDoubleTapEvent(event: MotionEvent?): Boolean {
        gesture_status.text = "onDoubleTapEvent"
        return true
    }

    //implementasi untuk sekali ketukan dikonfirmasi
    override fun onSingleTapConfirmed(event: MotionEvent?): Boolean {
        gesture_status.text = "onSingleTapConfirmed"
        return true
    }



}

